# demo: thinking -> non-thinking
# 4 * 70GiB; 40s/it
PYTORCH_CUDA_ALLOC_CONF='expandable_segments:True' \
NPROC_PER_NODE=4 \
CUDA_VISIBLE_DEVICES=0,1,2,3 \
megatron sft \
    --model ZhipuAI/GLM-4.5-Air \
    --save_safetensors true \
    --merge_lora true \
    --mtp_num_layers 1 \
    --dataset 'swift/Chinese-Qwen3-235B-2507-Distill-data-110k-SFT' \
    --load_from_cache_file true \
    --tuner_type lora \
    --lora_rank 32 \
    --lora_alpha 64 \
    --target_modules linear_qkv linear_proj \
    --split_dataset_ratio 0.01 \
    --moe_permute_fusion true \
    --tensor_model_parallel_size 4 \
    --expert_tensor_parallel_size 1 \
    --expert_model_parallel_size 4 \
    --moe_grouped_gemm true \
    --moe_shared_expert_overlap true \
    --moe_aux_loss_coeff 1e-3 \
    --micro_batch_size 1 \
    --global_batch_size 16 \
    --recompute_granularity full \
    --recompute_method uniform \
    --recompute_num_layers 1 \
    --num_train_epochs 2 \
    --finetune true \
    --cross_entropy_loss_fusion true \
    --lr 1e-4 \
    --lr_warmup_fraction 0.05 \
    --min_lr 1e-5 \
    --output_dir megatron_output/GLM-4.5-Air \
    --eval_steps 200 \
    --save_steps 200 \
    --packing true \
    --max_length 8192 \
    --dataloader_num_workers 8 \
    --dataset_num_proc 8 \
    --no_save_optim true \
    --no_save_rng true \
    --sequence_parallel true \
    --attention_backend flash

# If not using the MTP module, please remove the speculative-related parameters.
# CUDA_VISIBLE_DEVICES=0,1,2,3 \
# swift infer \
#     --model megatron_output/GLM-4.5-Air/vx-xxx/checkpoint-xxx-merged \
#     --sglang_tp_size 4 \
#     --infer_backend sglang \
#     --load_data_args true \
#     --sglang_context_length 8192 \
#     --max_new_tokens 2048 \
#     --sglang_mem_fraction_static 0.7 \
#     --sglang_speculative_algorithm EAGLE \
#     --sglang_speculative_eagle_topk 1 \
#     --sglang_speculative_num_steps 3 \
#     --sglang_speculative_num_draft_tokens 4
